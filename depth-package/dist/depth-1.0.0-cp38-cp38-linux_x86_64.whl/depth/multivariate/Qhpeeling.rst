.. _Qhpeeling:

Convex-hull-peeling depth
=========================

.. automodule:: Qhpeeling
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: count_convexes, is_in_convex
   
