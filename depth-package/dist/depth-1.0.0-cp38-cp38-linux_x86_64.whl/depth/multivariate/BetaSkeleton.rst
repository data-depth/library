.. _BetaSkeleton:

Beta-skeleton depth
===================

.. automodule:: BetaSkeleton
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: MCD_fun

.. _Yang and Modarres (2017): https://ideas.repec.org/a/spr/stpapr/v58y2017i3d10.1007_s00362-015-0715-x.html
