.. _Mahalanobis:

Mahalanobis depth
=================

.. automodule:: Mahalanobis
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: MCD_fun
   
