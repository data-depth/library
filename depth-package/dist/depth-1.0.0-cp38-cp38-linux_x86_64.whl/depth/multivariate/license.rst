License
=======

This entire Python library :math:`\texttt{data-depth}` is under the GNU General Public License, version 2 (or shortly GPL-2 license): https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
