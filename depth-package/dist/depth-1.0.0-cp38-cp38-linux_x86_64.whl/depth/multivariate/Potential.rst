.. _Potential:

Potential depth
===============

.. automodule:: Potential
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: MCD_fun, Maha_mcd, Maha_transform, Maha_moment
