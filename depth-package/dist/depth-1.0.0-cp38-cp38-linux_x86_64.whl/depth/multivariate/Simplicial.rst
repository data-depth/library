.. _Simplicial:

Simplicial depth
================

.. automodule:: Simplicial
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: longtoint
   
