.. _Aprojection:

Asymmetric projection depth
===========================

.. automodule:: Aprojection
   :members:
   :undoc-members:
   :show-inheritance:
