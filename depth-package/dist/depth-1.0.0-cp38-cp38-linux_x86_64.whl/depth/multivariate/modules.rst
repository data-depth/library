Multivariate
============

.. toctree::
   :maxdepth: 4

   Aprojection
   BetaSkeleton
   Halfspace
   L2
   Mahalanobis
   Potential
   Projection
   Qhpeeling
   Simplicial
   SimplicialVolume
   Spatial
   Zonoid
