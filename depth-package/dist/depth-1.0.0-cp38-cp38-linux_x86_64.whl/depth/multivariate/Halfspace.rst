.. _Halfspace:

Halfspace depth
===============

.. automodule:: Halfspace
   :members:
   :undoc-members:
   :show-inheritance:
