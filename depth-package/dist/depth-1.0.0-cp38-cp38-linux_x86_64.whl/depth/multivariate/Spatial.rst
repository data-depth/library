.. _Spatial:

Spatial depth
=============

.. automodule:: Spatial
   :members:
   :undoc-members:
   :show-inheritance:
